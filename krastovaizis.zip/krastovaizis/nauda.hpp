#ifndef __NAUDA_HPP_
#define __NAUDA_HPP_

#include <string>
#include <iostream>
#include <cstdint>
#include <math.h>
#include <vector>
#include "BMP24.h"


using namespace std;

// Tarpinė reikšmė  
double lerp(double a, double b, double t){
    return a * (1 - t) + b * t;
}
/////////////////////////////////////////////////////////////////////////////////////


// Spalvos klasė ir funkcijos
class Color{
   public:
     uint8_t r;
     uint8_t g;
     uint8_t b;
     Color():r(0),g(0),b(0){}
     Color(uint8_t r=0, uint8_t g=0, uint8_t b=0):r(r),g(g),b(b){}
};


Color lerpColor(Color a, Color b, double t){
    uint8_t r1 = (uint8_t) (a.r * (1 - t) + b.r * t);
    uint8_t g1 = (uint8_t) (a.g * (1 - t) + b.g * t);
    uint8_t b1 = (uint8_t) (a.b * (1 - t) + b.b * t);
    return Color(r1,g1,b1);
}

Color kombinacijaColor(Color a, Color b, Color c, double u, double v, double w){
    uint8_t r1 = (uint8_t) (a.r * u + b.r * v + c.r * w);
    uint8_t g1 = (uint8_t) (a.g * u + b.g * v + c.g * w);
    uint8_t b1 = (uint8_t) (a.b * u + b.b * v + c.b * w);
    return Color(r1,g1,b1);
}

/////////////////////////////////////////////////////////////////////////////////////

// Taško klasė ir funkcijos
class Taskas{
   public:
     double x;
     double y; 
     Taskas():x(0),y(0){}
     Taskas(double x=0, double y=0):x(x),y(y){}
};

double atstumas(Taskas a, Taskas b){
    Taskas d(b.x - a.x, b.y - a.y);
    return sqrt(d.x * d.x  + d.y * d.y);
}

// Vektorių AB ir AC sk. sandauga:
double skaliarineSandauga(Taskas A, Taskas B, Taskas C){
   Taskas AB(B.x-A.x, B.y-A.y);
   Taskas AC(C.x-A.x, C.y-A.y);
   return AB.x * AC.x  + AB.y * AC.y;
}

// Vektorių A ir B sk. sandauga:
double skaliarineSandauga(Taskas A, Taskas B){
   return A.x * B.x  + A.y * B.y;
}

// Vektoriaus AC projekcija į AB:
double projekcija(Taskas A, Taskas B, Taskas C){
   Taskas AB(B.x-A.x, B.y-A.y);
   Taskas AC(C.x-A.x, C.y-A.y);
   double csfi = skaliarineSandauga(A,B,C)/atstumas(A,B)/atstumas(A,C);
   
   return csfi*atstumas(A,C);
}

/////////////////////////////////////////////////////////////////////////////////////

// Spalvotas taškas - koordinatės + saplva
class SpalvotasTaskas{
   public:
     Taskas koordinates;
     Color spalva;
     SpalvotasTaskas():koordinates(Taskas(0,0)),spalva(Color(0,0,0)){}
     SpalvotasTaskas(Taskas k, Color sp):koordinates( k ),spalva(sp){}
     SpalvotasTaskas(double x, double y, uint8_t r, uint8_t g, uint8_t b)
             :koordinates(Taskas(x,y)), spalva(Color(r,g,b)){}

};
//////////////////////////////////////////////////////////////////////////////////////////////////////
// DObjektas klasė
// DObjektas - daugiakampių rinkinys
// 
class DObjektas{
    public:
      int kiek;
      vector<Taskas>* objektai;
      vector<Color> krastoSpalvos;
      vector<Color> dazuSpalvos;
      vector<Taskas> vidiniai;
      DObjektas(istream& failas){
          failas >> kiek;
          objektai = new vector<Taskas>[kiek];
          for (int i=0;i<kiek;i++){
             int r,g,b;

             failas >> r >> g >> b;
             krastoSpalvos.push_back(Color((uint8_t)r,(uint8_t)g,(uint8_t)b));
             
             failas >> r >> g >> b;
             dazuSpalvos.push_back(Color((uint8_t)r,(uint8_t)g,(uint8_t)b));
             
             Taskas vidinis(0,0);
             failas >> vidinis.x >> vidinis.y;             
             vidiniai.push_back(vidinis);

             int kiekTasku;
             failas >> kiekTasku;          
             
             for(int j=0;j<kiekTasku;j++){
                double x,y;
                failas >> x >> y;
                objektai[i].push_back(Taskas(x,y));
             }
          
          }
      }
            
      ~DObjektas(){
          delete[] objektai;
      }

};





//////////////////////////////////////////////////////////////////////////////////////////////////////

// Radialinio gradiento klasė
class RadialinisGradientas{
   public:
     SpalvotasTaskas centras;
     Color krastas;     
     double R;     
     RadialinisGradientas():centras(SpalvotasTaskas(0,0, 0,0,0)),krastas(255,255,255), R(10){}
     RadialinisGradientas(double x, double y, uint8_t rc, uint8_t gc, uint8_t bc, uint8_t rk, uint8_t gk, uint8_t bk, double R = 100 ):
          centras(SpalvotasTaskas(x,y,rc,gc,bc)), krastas(Color(rk,gk,bk)), R(R){}   
     Color skaiciuokSpalva(Taskas p){
        double ats = atstumas(p, this->centras.koordinates);
        double t = ats/R;
        if (t > 1.0)  
            return krastas;
        else 
            return lerpColor(this->centras.spalva, krastas, t);
     }     
};

/////////////////////////////////////////////////////////////////////////////////////

// Tiesinio gradiento klasė
class TiesinisGradientas{
   public:
     SpalvotasTaskas pirmas;
     SpalvotasTaskas antras;
     TiesinisGradientas():pirmas(SpalvotasTaskas(0,0, 0,0,0)),antras(SpalvotasTaskas(100,100, 255,255,255)){}
     TiesinisGradientas(double x1, double y1, uint8_t r1, uint8_t g1, uint8_t b1, 
                        double x2, double y2, uint8_t r2, uint8_t g2, uint8_t b2):
          pirmas(SpalvotasTaskas(x1,y1,r1,g1,b1)), antras(SpalvotasTaskas(x2,y2,r2,g2,b2)){}   
     Color skaiciuokSpalva(Taskas p){
        double ats = atstumas(this->pirmas.koordinates, this->antras.koordinates);
        double pr = projekcija(this->pirmas.koordinates, this->antras.koordinates, p);
        if (pr < 0.0)  
            return this->pirmas.spalva;
        else if (pr > ats)
            return this->antras.spalva;
            else{
                  double t =  pr / ats;
                  return lerpColor(this->pirmas.spalva, this->antras.spalva, t);
                } 
                
     }     
};

/////////////////////////////////////////////////////////////////////////////////////

// Transformacijos klasė
class Transformacija{
   public:
     double  a;
     double  b;
     double  c;
     double  d;
     double  e;
     double  f;
     Transformacija():a(1),b(0),c(0),d(0),e(1),f(0){}
     Transformacija(double a, double b, double c, double d, double e, double f):
         a(a),b(b),c(c),d(d),e(e),f(f){}
    
     void vienetine(){
       a = 1;  b = 0; c = 0; d = 0; e = 1; f = 0;
     }
     void pernesimas(double xc, double yc){
         c += xc;
         f += yc;
     }
     void mastelis(double xm, double ym){
         a *= xm;
         e *= ym;
     }
     void posukis(double laipsniu){
         double rad = laipsniu * M_PI/180;
         double cs = cos(rad);
         double sn = sin(rad);
         double a1 = cs * a - sn * d; 
         double b1 = cs * b - sn * e;  
         double d1 = sn * a + cs * d; 
         double e1 = sn * b + cs * e;  
         a = a1; b = b1; d = d1; e = e1;
     }
     void pritaikyk(Taskas& p){
        double x1 = p.x * a + p.y * b + c; 
        double y1 = p.x * d + p.y * e + f;
        p.x = x1;
        p.y = y1;
     } 


};

/////////////////////////////////////////////////////////////////////////////////////

//  Kavdrato piešimo funkcijos 
// ... pagal spalvą
void kvadratas(BMP24& pav, double did, Color c, Transformacija tr){
   double delta = 0.1;
   
   for(double x = 0; x < did; x+=delta)
     for(double y = 0; y < did; y+=delta){
          Taskas p(x,y);
          tr.pritaikyk(p);           
          pav.dekTaska((uint32_t) p.x, (uint32_t) p.y, c.r, c.g, c.b);  
     }     
}

// ... pagal tiesinį gradientą 
void kvadratas(BMP24& pav, double did, TiesinisGradientas gr, Transformacija tr){
   double delta = 0.1;
   
   for(double x = 0; x < did; x+=delta)
     for(double y = 0; y < did; y+=delta){
          Taskas p(x,y);
          tr.pritaikyk(p);           
          Color c = gr.skaiciuokSpalva(p);
          pav.dekTaska((uint32_t) p.x, (uint32_t) p.y, c.r, c.g, c.b);  
     }     
}


/////////////////////////////////////////////////////////////////////////////////////
// Elipsės piešimo funkcijos

void elipse(BMP24& pav, double a, double b, Color c, Transformacija tr){
   double delta = 0.1;
   
   for(double x = -a; x < a; x+=delta)
     for(double y = -b; y < b; y+=delta){
          if ((x*x/a/a + y*y/b/b)<=1.0){
             Taskas p(x,y);
             tr.pritaikyk(p);           
             pav.dekTaska((uint32_t) p.x, (uint32_t) p.y, c.r, c.g, c.b);  
          }   
     }     
}

/////////////////////////////////////////////////////////////////////////////////////
// Atkarpos piešimo funkcija

void atkarpa(BMP24& pav, Taskas a, Taskas b, Color c){
   double lx = fabs(a.x-b.x);
   double ly = fabs(a.y-b.y);
   double dt = 1.0/(1.0+2 * lx + 2 * ly);
   
   for(double t=0; t<=1.0;t+=dt){
      Taskas p(lerp(a.x, b.x, t), lerp(a.y, b.y, t));
      pav.dekTaska((uint32_t) p.x, (uint32_t) p.y, c.r, c.g, c.b);  
   }
}


/////////////////////////////////////////////////////////////////////////////////////
// Bezier2 piešimo funkcija

void bezier2(BMP24& pav, Taskas p1, Taskas ctrl, Taskas p2, Color c){
   double P1Ctrl = atstumas(p1, ctrl);
   double P2Ctrl = atstumas(p2, ctrl);
   
   double dt = 1.0/(1.0+2 * P1Ctrl + 2 * P2Ctrl);
   
   for(double t=0; t<=1.0;t+=dt){
      double t1sq = (1-t) * (1-t);
      double tsq = t * t;
      double t1t = (1-t) * t;
    
      double x = p1.x * t1sq + 2 * ctrl.x * t1t + p2.x * tsq;
      double y = p1.y * t1sq + 2 * ctrl.y * t1t + p2.y * tsq; 
      
      Taskas p(x,y);
      pav.dekTaska((uint32_t) p.x, (uint32_t) p.y, c.r, c.g, c.b);  
   }
}

/////////////////////////////////////////////////////////////////////////////////////
// Bezier2 piešimo funkcija

void bezier3(BMP24& pav, Taskas p1, Taskas ctrl1, Taskas ctrl2, Taskas p2, Color c){
   double P1Ctrl1 = atstumas(p1, ctrl1);
   double P2Ctrl2 = atstumas(p2, ctrl2);
   double Ctrl12 = atstumas(ctrl1, ctrl2);
   
   
   double dt = 1.0/(1.0+2 * P1Ctrl1 + 2 * P2Ctrl2 + 2 * Ctrl12);
   
   for(double t=0; t<=1.0;t+=dt){
      double t1c = (1-t) * (1-t) * (1-t);
      double tc = t * t * t;
      double t1sqt = (1-t) * (1 - t) * t;
      double tsqt1 = (1-t) * t * t;
      
    
      double x = p1.x * t1c + 3 * ctrl1.x * t1sqt + 3 * ctrl2.x * tsqt1 + p2.x * tc;
      double y = p1.y * t1c + 3 * ctrl1.y * t1sqt + 3 * ctrl2.y * tsqt1 + p2.y * tc;
      
      Taskas p(x,y);
      pav.dekTaska((uint32_t) p.x, (uint32_t) p.y, c.r, c.g, c.b);  
   }
}

/////////////////////////////////////////////////////////////////////////////////////

// Trikampio piešimo funkcijos
// ... pagal spalvą ir viršūnes 
void trikampis(BMP24& pav, Taskas a, Taskas b, Taskas c, Color sp, Transformacija tr){
   double lx = fabs(a.x-b.x);
   double ly = fabs(a.y-b.y);
   double dt = 1.0/(1.0+2 * lx + 2 * ly);
   tr.pritaikyk(c);          
   for(double t=0; t<=1.0;t+=dt){
      Taskas p(lerp(a.x, b.x, t), lerp(a.y, b.y, t));
      tr.pritaikyk(p);          
      atkarpa(pav, c, p, sp);  
   }
}

// Laužtės piešimo funkcijos
// ... pagal spalvą ir viršūnes 
void lauzte(BMP24& pav, vector<Taskas>& taskai, Color sp, Transformacija tr, bool arUzdara = false){
   int len = taskai.size() - 1;
   for( int i = 0; i < len; i++){
      Taskas a = taskai[i];
      Taskas b = taskai[i+1];
      tr.pritaikyk(a);          
      tr.pritaikyk(b);          
      atkarpa(pav, a, b, sp);  
   }
   if (arUzdara){
      Taskas a = taskai[len];
      Taskas b = taskai[0];
      tr.pritaikyk(a);          
      tr.pritaikyk(b);          
      atkarpa(pav, a, b, sp);  
   }
   
}


// ... pagal radialinį gradientą ir viršūnes 
void trikampis(BMP24& pav, Taskas a, Taskas b, Taskas c, RadialinisGradientas gr, Transformacija tr){
   double lx = fabs(a.x-b.x);
   double ly = fabs(a.y-b.y);
   double dt = 1.0/(1.0+2 * lx + 2 * ly);
   tr.pritaikyk(c);          
   for(double t=0; t<=1.0;t+=dt){
      Taskas p(lerp(a.x, b.x, t), lerp(a.y, b.y, t));
      tr.pritaikyk(p);          
      Color sp = gr.skaiciuokSpalva(p);
      atkarpa(pav, c, p, sp);  
   }
}


void baricentrinesKoordinates(Taskas p, Taskas a, Taskas b, Taskas c, double &u, double &v, double &w)
{
    double ABAB = skaliarineSandauga(a,b,b);
    double ABAC = skaliarineSandauga(a,b,c);
    double ACAC = skaliarineSandauga(a,c,c);
    double APAB = skaliarineSandauga(a,b,p);
    double APAC = skaliarineSandauga(a,c,p);
    double vardkl = ABAB * ACAC - ABAC * ABAC;
    v = (ACAC * APAB - ABAC * APAB) / vardkl;
    w = (ABAB * APAC - ABAC * APAB) / vardkl;
    u = 1.0 - v - w;
    //cout << u << " " << v << " " << w << endl;
    
    Taskas v0(b.x - a.x, b.y - a.y);
    Taskas v1(c.x - a.x, c.y - a.y);
    Taskas v2(p.x - a.x, p.y - a.y);

    double d00 = skaliarineSandauga(v0, v0);
    double d01 = skaliarineSandauga(v0, v1);
    double d11 = skaliarineSandauga(v1, v1);
    double d20 = skaliarineSandauga(v2, v0);
    double d21 = skaliarineSandauga(v2, v1);
    double denom = d00 * d11 - d01 * d01;
    v = (d11 * d20 - d01 * d21) / denom;
    w = (d00 * d21 - d01 * d20) / denom;
    u = 1.0 - v - w;
    //cout << u << " " << v << " " << w << endl;
   

}

// ... pagal spalvotas viršūnes  (naudojamos baricentriės koordinatės)
void trikampis(BMP24& pav, SpalvotasTaskas a, SpalvotasTaskas b, SpalvotasTaskas c, Transformacija tr){
   double lx = fabs(a.koordinates.x-b.koordinates.x);
   double ly = fabs(a.koordinates.y-b.koordinates.y);
   double dt = 1.0/(1.0+2 * lx + 2 * ly);
   tr.pritaikyk(c.koordinates);          
   for(double t=0; t<=1.0;t+=dt){
      Taskas p(lerp(a.koordinates.x, b.koordinates.x, t), lerp(a.koordinates.y, b.koordinates.y, t));
      tr.pritaikyk(p);          
      double u,v,w;
      baricentrinesKoordinates(p, a.koordinates,  b.koordinates, c.koordinates, u, v, w);
      Color sp = kombinacijaColor(a.spalva, b.spalva, c.spalva, u, v, w);
      atkarpa(pav, c.koordinates, p, sp);  
   }

}


/////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

void horizontaliTiese(BMP24& pav, uint32_t xL, uint32_t xR, uint32_t y, 
                      uint8_t r, uint8_t g, uint8_t b){
      uint32_t xXL = xL;
      uint32_t xXR = xR;

      uint32_t  yY = y;
      for(uint32_t xX = xXL;  xX <= xXR;  xX++){
            uint32_t vieta =  xX * 3 + pav.eilutesIlgis  * yY;  
            pav.vaizdas[ vieta ] = b;
            pav.vaizdas[ vieta + 1] = g;
            pav.vaizdas[ vieta + 2] = r;
      }
   }


/////////////////////////////////////////////////////////////////////////////////////////////////////
// Spalvinimas: (rekursinis-linijinis)
uint32_t  rekursinisLinijinisSpalvinimas(BMP24& pav, 
                       uint32_t vidinisX, uint32_t vidinisY, 
                       uint32_t kryptis, 
                       uint32_t buvesXL, uint32_t buvesXR, 
                       uint8_t rKonturo, uint8_t gKonturo, uint8_t bKonturo, 
                       uint8_t rDazu,   uint8_t gDazu,   uint8_t bDazu) 
{ 
          uint8_t tR,tG,tB; 
          uint32_t x = vidinisX; 
          uint32_t xr=x, xl=x; 
          do { 
             pav.duokTaskoSpalva( --xl, vidinisY, tR,tG,tB); 
          } 
          while (( 
               ( rKonturo != tR) ||   ( gKonturo != tG)  || ( bKonturo != tB)) && 
               ( ( rDazu != tR) ||   ( gDazu != tG)  || ( bDazu != tB))); 
 
 
          do 
             pav.duokTaskoSpalva( ++xr, vidinisY, tR,tG,tB); 
          while (  
               (( rKonturo != tR) ||  ( gKonturo != tG)  || ( bKonturo != tB)) && 
               ( ( rDazu != tR) ||   ( gDazu != tG)  || ( bDazu != tB))); 
 
         xl++; xr--; 
         
         horizontaliTiese(pav, xl,xr,vidinisY,rDazu,gDazu,bDazu); 

         for(x=xl;x<=xr;x++){ 
           pav.duokTaskoSpalva( x, vidinisY + kryptis, tR,tG,tB); 
           if  (( ( rKonturo != tR) ||   ( gKonturo != tG)  || ( bKonturo != tB)) && 
                      ( ( rDazu != tR) ||   ( gDazu != tG)  || ( bDazu != tB))) {
                rekursinisLinijinisSpalvinimas(pav,   x,  vidinisY + kryptis, 
                                             kryptis, xl, xr, 
                                             rKonturo, gKonturo, bKonturo, 
                                             rDazu, gDazu, bDazu ); 
           } 
        } 

        for(x=xl;x <= buvesXL; x++){ 
           pav.duokTaskoSpalva(x, vidinisY - kryptis, tR,tG,tB); 
           if  (( ( rKonturo != tR) ||   ( gKonturo != tG)  || ( bKonturo != tB)) &&
               ( ( rDazu != tR) ||   ( gDazu != tG)  || ( bDazu != tB))) { 
           x =   rekursinisLinijinisSpalvinimas(pav,   x,  vidinisY - kryptis, 
                                             -kryptis, xl, xr, 
                                             rKonturo, gKonturo, bKonturo, 
                                             rDazu, gDazu, bDazu ); 
         } 
        } 
 
         for(x=buvesXR; x <= xr; x++){ 
           pav.duokTaskoSpalva(x, vidinisY - kryptis, tR,tG,tB); 
           if  (( ( rKonturo != tR) ||   ( gKonturo != tG)  || ( bKonturo != tB)) && 
                ( ( rDazu != tR) ||   ( gDazu != tG)  || ( bDazu != tB))) { 
           x =   rekursinisLinijinisSpalvinimas(pav,   x,  vidinisY - kryptis, 
                                             -kryptis, xl, xr, 
                                             rKonturo, gKonturo, bKonturo, 
                                             rDazu, gDazu, bDazu ); 
          } 
        } 
 
       return xr; 
 
} 

////////////////////////////////////////////////////////////////////////


void spalvink(BMP24& pav, 
            uint32_t x, uint32_t y, 
            uint32_t rKonturo, uint32_t  gKonturo, 
            uint8_t  bKonturo, uint8_t  rDazu, uint8_t  gDazu, uint8_t  bDazu ) 
{

     rekursinisLinijinisSpalvinimas(pav, 
                         x,y,1,x,x,
                         rKonturo, gKonturo, bKonturo, 
                         rDazu, gDazu, bDazu);

     return;
}


////////////////////////////////////////////////////////////////////////
void spalvink(BMP24& pav, Taskas vidinis,  Color krasto, Color dazu)
{
     uint32_t x = (uint32_t) vidinis.x;
     uint32_t y = (uint32_t) vidinis.y;
     uint8_t rKonturo = (uint8_t)  krasto.r;
     uint8_t gKonturo = (uint8_t)  krasto.g;
     uint8_t bKonturo = (uint8_t)  krasto.b;
     
     uint8_t rDazu = (uint8_t)  dazu.r;
     uint8_t gDazu = (uint8_t)  dazu.g;
     uint8_t bDazu = (uint8_t)  dazu.b;
    
     rekursinisLinijinisSpalvinimas(pav, 
                         x,y,1,x,x,
                         rKonturo, gKonturo, bKonturo, 
                         rDazu, gDazu, bDazu);
     return;
}



////////////////////////////////////////////////////////////////////////
void daugiakampis(BMP24& pav, vector<Taskas>& virsunes,  Taskas vidinis, Color krasto, Color dazu, Transformacija tr)
{
     Taskas vid = vidinis;
     lauzte(pav, virsunes, krasto, tr, true);
     tr.pritaikyk(vid);
     spalvink(pav, vid,  krasto, dazu);
     return;
}


////////////////////////////////////////////////////////////////////////
void pieskDObjekta(BMP24& pav, const DObjektas& obj, Transformacija tr)
{
     
     int kiek = obj.kiek;
     for(int i=0; i<kiek; i++){
        cout << obj.vidiniai[i].x << " " << obj.vidiniai[i].y << endl;
        daugiakampis(pav, obj.objektai[i],  obj.vidiniai[i], obj.krastoSpalvos[i], obj.dazuSpalvos[i], tr);   
     }
     return;
}




/////////////////////////////////////////////////////////////////////////////////////
#endif
