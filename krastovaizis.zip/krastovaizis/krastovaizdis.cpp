#include <math.h>
#include "BMP24.h"
#include <cstdint>
#include "nauda.hpp"
#include <random>
#include <cmath>
#include <vector>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstdint>


double random_double(double lower_bound=0, double upper_bound=1.0) {
   std::random_device rd;
   std::mt19937 gen(rd());
   std::uniform_real_distribution<> dist(lower_bound, upper_bound);

   return dist(gen);
}

int random_int(int lower_bound, int upper_bound) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dist(lower_bound, upper_bound);

    return dist(gen);
}

void zvaigzde(BMP24& pav, Transformacija tr){
   // TiesinisGradientas gr_medis(0,480, 0,0,0, 0, 200, 0, 0,0);
   // kvadratas(pav, 10, gr_medis, tr);
   trikampis(pav, SpalvotasTaskas(-20,20,255,255,255), SpalvotasTaskas(0,100,0,0,255), SpalvotasTaskas(20,20,255,255,255), tr);
   trikampis(pav, SpalvotasTaskas(-20,-20,255,255,255), SpalvotasTaskas(0,-100,0,0,255), SpalvotasTaskas(20,-20,255,255,255), tr);
   trikampis(pav, SpalvotasTaskas(-20,20,255,255,255), SpalvotasTaskas(-100,0,0,0,255), SpalvotasTaskas(-20,-20,255,255,255), tr);
   trikampis(pav, SpalvotasTaskas(20,20,255,255,255), SpalvotasTaskas(100,0,0,0,255), SpalvotasTaskas(20,-20,255,255,255), tr);
}

void egle(BMP24& pav, int n, Transformacija tr){
   if(n>5){
      n = 5;
   }

   for(int i = 0; i < n; i++ ){
      trikampis(pav, SpalvotasTaskas(-50+10*i,i*20,0,50,0), SpalvotasTaskas(0,20+20*i,0,255,0), SpalvotasTaskas(50-10*i,i*20,0,50,0), tr);
   }
}


#include <vector>
#include <cmath>
// Include other necessary headers and namespaces

// void banga(BMP24& pav, int n, Transformacija tr) {
//    tr.mastelis(0.5,0.5);
//     // Generate the Fibonacci sequence
//     std::vector<int> fibs = {0, 1};
//     for (int i = 2; i < n; ++i) {
//         fibs.push_back(fibs[i-1] + fibs[i-2]);
//     }

//     double angleStep = M_PI / 6; // Adjust this value to control the spiral effect
//     double scale = 1.0; // Adjust the scale to control the size of the triangles
    
//     // Calculate the initial angle to ensure the biggest triangle is at the bottom left
//     double initialAngle = -M_PI / 2 - (angleStep * (n - 1));
//     double angle = initialAngle;

//     for (int i = 0; i < n; ++i) {
//         // Define the right triangle vertices
//         double x1 = 50 + scale * fibs[i];
//         double y1 = 50;

//         double x2 = 50 + scale * fibs[i];
//         double y2 = 50 + scale * fibs[i];

//         double x3 = 50;
//         double y3 = 50 + scale * fibs[i];

//         // Applying rotation transformations
//         double x1_rot = 50 + (x1 - 50) * cos(angle) - (y1 - 50) * sin(angle);
//         double y1_rot = 50 + (x1 - 50) * sin(angle) + (y1 - 50) * cos(angle);

//         double x2_rot = 50 + (x2 - 50) * cos(angle) - (y2 - 50) * sin(angle);
//         double y2_rot = 50 + (x2 - 50) * sin(angle) + (y2 - 50) * cos(angle);

//         double x3_rot = 50 + (x3 - 50) * cos(angle) - (y3 - 50) * sin(angle);
//         double y3_rot = 50 + (x3 - 50) * sin(angle) + (y3 - 50) * cos(angle);

//         Color col = Color(60, 60, 10 * i);
//         SpalvotasTaskas p1(x1_rot, y1_rot, col.r, col.g, col.b);
//         SpalvotasTaskas p2(x2_rot, y2_rot, col.r, col.g, col.b);
//         SpalvotasTaskas p3(x3_rot, y3_rot, col.r, col.g, col.b);

//         trikampis(pav, p1, p2, p3, tr);
        
//         // Update angle and scale for the next iteration
//         angle += angleStep;
//         scale *= 0.9; // Adjust this value to control the shrinking of triangles
//     }
// }





//////////////////////////////////MAIN///////////////////////////////////

string vardas(uint32_t skaicius){ // iki 1000 kadru

    stringstream ss;
    ss << setw(3) << std::setfill('0') << skaicius;
    return ss.str();
}
int main(){
   int base_mast = 1;
   for(int k=1;k<=15;k++){
      srandom(time(NULL));
      BMP24 pav(640, 480);
      pav.valyk(128,128,128+k);
      Transformacija tr;
      tr.pernesimas(100+k*5, 240);   
      elipse(pav, 20, 10, Color(255,128,0), tr);      
      if (k % 20 < 5){
         Transformacija tr;
         tr.pernesimas(100+k*5, 235);   
         elipse(pav, 4, 3, Color(255,0,0), tr);      
      }



      tr.vienetine();
      tr.pernesimas(0,200);
      TiesinisGradientas gr_dangus(0,480, 11,0,51, 0, 200, 53, 92,103);
      tr.mastelis(640.0/280.0,1);
      kvadratas(pav, 280, gr_dangus, tr);

      int n = 200;
      for (int i=0; i < n; i++){
         random_double(0,1.0);
         tr.vienetine();
         tr.pernesimas((random_int(20,600)),(random_int(0,280)+180));
         double mast = random_double(0.001,0.1);
         tr.mastelis(mast,mast);
         tr.posukis((random_int(0,360)));
         zvaigzde(pav,tr);
      }


      tr.vienetine();
      tr.pernesimas((320),(160));

      Color pilka = Color(240,240,240);

      elipse(pav,100,100,pilka,tr);

      tr.vienetine();
      TiesinisGradientas gr_pieva(0, 0, 60,60,180, 0, 200, 120, 120,230);
      tr.mastelis(3.2,1);
      Color c = Color(161,192,132);
      kvadratas(pav, 200, gr_pieva, tr);

      int new_y = 190;
      while(new_y>10){
         tr.vienetine();
         if(((190-new_y)+(6*k)) % 12 ==0){
            tr.posukis(-1);
         }
         else{
            tr.posukis(1);
         }
         tr.pernesimas((320),new_y);
         elipse(pav,315,2,Color(60,60,180),tr);
         new_y -= 6;
      }

      int plotis = 90;
      int melyna = 205;
      new_y = 190;
      int spalva = 180;
      for(int i = 0; i<15;i++){
         tr.vienetine();
         if((i+k)%2==1){
            tr.posukis(1);
         }
         else{
            tr.posukis(-1);
         }
         tr.pernesimas((320),new_y);
         pilka = Color(spalva,spalva,melyna);
         elipse(pav,plotis,2,pilka,tr);
         plotis -= 1*i;
         melyna += 3;
         spalva -=2;
         new_y -= 6;
      }


      ifstream fin("./vaizdai/banga.obk");
      DObjektas banga(fin);
      fin.close();

      n=3;
      for(int i = 0; i<n;i++){
         tr.vienetine();
         tr.pernesimas(((k*20)+(i*i*10)),170-(i*80));
         if(0.4+(i*0.2)-(k*0.05)<=0.01){
            tr.mastelis(1+(i*0.2),1+(i*0.2)-(k*0.05)); 
            if(1+(i*0.2),1+(i*0.2)-(k*0.05)<=0.01){
               tr.mastelis(1.6+(i*0.2),1.6+(i*0.2)-(k*0.05)); 
            }
         }
         else{
            tr.mastelis(0.4+(i*0.2),0.4+(i*0.2)-(k*0.05)); 
         }
         pieskDObjekta(pav, banga, tr);
      }


      // tr.vienetine();
      // tr.mastelis(1,1);
      // tr.pernesimas(0,100);
      // banga(pav,k+5,tr);

      // tr.vienetine();
      // tr.mastelis(1,1);
      // tr.pernesimas(200,100);
      // banga(pav,10,tr);

      // int new_y = 200;
      // double new_mast = 0.2;
      // n = 40;
      // while(new_y > 100){
      //    new_y -= 5;
      //    new_mast = new_mast * 1.03;
      //    n -=1;

      //    for(int i = 0; i<n;i++){
      //    tr.vienetine();
      //    double mast_var = random_double(0.01,0.03);
      //    tr.mastelis(new_mast+mast_var,new_mast+mast_var);
      //    tr.pernesimas(random_int(20,600),new_y);
      //    egle(pav,4,tr);
      //    }
      // }
      pav.rasykIByla("a-"+vardas(k)+".bmp");

   }
   system("ffmpeg -framerate 5 -i a-%03d.bmp video.webm");
   system("rm a-*.bmp");
 
   return 0;  
}
